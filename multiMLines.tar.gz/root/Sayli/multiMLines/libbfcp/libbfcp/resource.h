//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by libbfcp.rc
//
#define IDD_DIALOG_BFCP_WINDOW_SHARING  101
#define IDB_BITMAP_LIVE                 105
#define IDB_BITMAP_PRESENTATION         106
#define IDB_BITMAP_LIVE_DISABLE         107
#define IDB_BITMAP_PRESENTATION_DISABLE 108
#define IDB_BITMAP_LIVE_DISABLE1        109
#define IDB_BITMAP_PRESENTATION_DISABLE1 110
#define IDC_BUTTON_LIVE_CONTENT         1015
#define IDC_BUTTON_PRESENTATION_CONTENT 1016
#define IDC_STATIC_BORDER               1022
#define IDC_STATIC_PRESENTATION         1024
#define IDC_STATIC_LIVE                 1025
#define IDC_LIST_WINDOWS                1026
#define IDC_BTN_REFRESH                 1027
#define IDC_BTN_VIDEOOPTIONS            1028
#define IDC_BTN_SENDINTRA               1029
#define IDC_STATIC_VIDEOQUALITY         1030
#define IDC_STATIC_SENDINTRA            1031
#define IDC_CK_ALLOW_1024_768           1032
#define IDC_CK_ALLOW_640_480            1033
#define IDC_VIDEO_QUALITY               1070
#define IDS_TXT_FONT_NAME               1207
#define IDS_TXT_FONT_SIZE               1208
#define IDS_TXT_PRESENTATION            1209
#define IDS_TXT_LIVE                    1210
#define IDS_BTN_REFRESH_LIST            1211
#define IDS_PLUGIN_TITLE                1212
#define IDS_BTN_VIDEOOPTION_OFF         1213
#define IDS_BTN_VIDEOOPTION_ON          1214

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
#define BUILD_WITH_PTLIB 0
