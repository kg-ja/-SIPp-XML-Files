#ifndef BFCP_PORTING_H
#define BFCP_PORTING_H

#ifdef WIN32
#include "ftcplateform.h"
#include "ftccriticalsection.h"

#endif // WIN32

#endif // BFCP_PORTING_H